<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SlideShare Downloader</title>
</head>
<body>
    <div class="slideshare-downloader-container">
        <div class="slideshare-container">
            <h1>SlideShare Downloader</h1>
            <p>Download slides from SlideShare presentations easily.</p>
            
            <form id="slideshare-form">
                <div class="form-group">
                    <label for="slideshare-url">SlideShare URL:</label>
                    <input type="text" id="slideshare-url" placeholder="Enter SlideShare URL" required>
                </div>
                
                <div class="form-group">
                    <label for="slideshare-quality">Quality:</label>
                    <select id="slideshare-quality">
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <span id="advanced-options-toggle" class="toggle-link">Advanced Options</span>
                    <div id="advanced-options" class="advanced-options">
                        <div class="form-group">
                            <label for="slide-range">Slide Range (e.g., 1-5,7,9):</label>
                            <input type="text" id="slide-range" placeholder="Optional - enter specific slides to include">
                        </div>
                        
                        <div class="form-group">
                            <label for="pdf-password">PDF Password Protection:</label>
                            <input type="text" id="pdf-password" placeholder="Optional - password protect PDF">
                        </div>
                        
                        <div class="form-group">
                            <label for="custom-filename">Custom Filename:</label>
                            <input type="text" id="custom-filename" placeholder="Optional - custom filename for download">
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn">Download Slides</button>
            </form>
            
            <div id="slideshare-loading" class="loading">
                <div class="spinner"></div>
                <p class="loading-message">Loading...</p>
            </div>
            
            <div id="status-message" class="status-message"></div>
            
            <div id="slideshare-results" class="results">
                <h2>Download Options</h2>
                
                <form id="download-form">
                    <div id="download-options" class="download-controls">
                        <div class="format-options">
                            <div class="format-option">
                                <input type="radio" id="format-pdf" name="download-format" value="pdf" checked>
                                <label for="format-pdf">PDF</label>
                            </div>
                            
                            <div class="format-option">
                                <input type="radio" id="format-ppt" name="download-format" value="ppt">
                                <label for="format-ppt">PowerPoint</label>
                            </div>
                            
                            <div class="format-option">
                                <input type="radio" id="format-zip" name="download-format" value="zip">
                                <label for="format-zip">ZIP (Images)</label>
                            </div>
                        </div>
                        
                        <div class="selection-controls">
                            <button type="button" id="select-all-slides" class="btn btn-secondary">Select All</button>
                            <button type="button" id="deselect-all-slides" class="btn btn-secondary">Deselect All</button>
                            <button type="submit" class="btn btn-success">Generate Download</button>
                        </div>
                    </div>
                </form>
                
                <div id="download-link-container"></div>
                
                <div class="slide-controls">
                    <button id="back-button" class="btn btn-secondary">Back to Search</button>
                </div>
                
                <h3>Available Slides</h3>
                <div id="slides-container" class="slide-grid"></div>
            </div>
        </div>
    </div>
</body>
</html>
