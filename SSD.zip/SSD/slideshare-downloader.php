<?php
/**
 * Plugin Name: SlideShare Downloader
 * Description: A tool to download slides from SlideShare
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class SlideShare_Downloader {
    
    private $download_dir;
    
    public function __construct() {
        // Set up directory for temporary files
        $upload_dir = wp_upload_dir();
        $this->download_dir = $upload_dir['basedir'] . '/slideshare-downloads';
        
        if (!file_exists($this->download_dir)) {
            wp_mkdir_p($this->download_dir);
        }
        
        // Register shortcode
        add_shortcode('slideshare_downloader', array($this, 'render_downloader_form'));
        
        // Register AJAX actions
        add_action('wp_ajax_fetch_slideshare', array($this, 'ajax_fetch_slideshare'));
        add_action('wp_ajax_nopriv_fetch_slideshare', array($this, 'ajax_fetch_slideshare'));
        
        add_action('wp_ajax_generate_download', array($this, 'ajax_generate_download'));
        add_action('wp_ajax_nopriv_generate_download', array($this, 'ajax_generate_download'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // Add cleanup via cron
        add_action('slideshare_cleanup_hook', array($this, 'cleanup_old_files'));
        
        if (!wp_next_scheduled('slideshare_cleanup_hook')) {
            wp_schedule_event(time(), 'daily', 'slideshare_cleanup_hook');
        }
    }
    
    public function enqueue_assets() {
        wp_enqueue_style('slideshare-downloader-css', plugin_dir_url(__FILE__) . 'assets/css/style.css', array(), '1.0.0');
        wp_enqueue_script('slideshare-downloader-js', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'), '1.0.0', true);
        
        wp_localize_script('slideshare-downloader-js', 'slideshare_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('slideshare-downloader-nonce')
        ));
    }
    
    public function render_downloader_form() {
        ob_start();
        include plugin_dir_path(__FILE__) . 'templates/downloader-form.php';
        return ob_get_clean();
    }
    
    public function ajax_fetch_slideshare() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'slideshare-downloader-nonce')) {
            wp_send_json_error('Security check failed');
        }
        
        $url = isset($_POST['url']) ? sanitize_text_field($_POST['url']) : '';
        $quality = isset($_POST['quality']) ? sanitize_text_field($_POST['quality']) : 'medium';
        
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            wp_send_json_error('Invalid URL provided');
        }
        
        try {
            $slide_images = $this->get_slide_images($url, $quality);
            
            if (empty($slide_images)) {
                wp_send_json_error('No slides found in the provided URL');
            }
            
            // Create a session ID for this extraction
            $session_id = $this->generate_session_id();
            update_option('slideshare_session_' . $session_id, array(
                'url' => $url,
                'quality' => $quality,
                'images' => $slide_images,
                'timestamp' => time()
            ));
            
            // Prepare response data
            $slides_data = array();
            foreach ($slide_images as $index => $image_url) {
                $slides_data[] = array(
                    'id' => $index + 1,
                    'url' => $image_url,
                    'selected' => true
                );
            }
            
            wp_send_json_success(array(
                'session_id' => $session_id,
                'total_slides' => count($slide_images),
                'slides' => $slides_data
            ));
            
        } catch (Exception $e) {
            wp_send_json_error('Error processing SlideShare URL: ' . $e->getMessage());
        }
    }
    
    public function ajax_generate_download() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'slideshare-downloader-nonce')) {
            wp_send_json_error('Security check failed');
        }
        
        $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $format = isset($_POST['format']) ? sanitize_text_field($_POST['format']) : 'pdf';
        $selected_slides = isset($_POST['slides']) ? array_map('intval', $_POST['slides']) : array();
        
        // Advanced options
        $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';
        $custom_filename = isset($_POST['filename']) ? sanitize_text_field($_POST['filename']) : '';
        $slide_range = isset($_POST['slide_range']) ? sanitize_text_field($_POST['slide_range']) : '';
        
        if (empty($session_id) || empty($selected_slides)) {
            wp_send_json_error('Missing required data');
        }
        
        // Get session data
        $session_data = get_option('slideshare_session_' . $session_id);
        if (!$session_data) {
            wp_send_json_error('Session expired or invalid');
        }
        
        // Filter images by selected slides
        $image_urls = array();
        foreach ($selected_slides as $slide_index) {
            if (isset($session_data['images'][$slide_index - 1])) {
                $image_urls[] = $session_data['images'][$slide_index - 1];
            }
        }
        
        // Apply slide range if provided
        if (!empty($slide_range)) {
            $image_urls = $this->apply_slide_ranges($image_urls, $slide_range);
        }
        
        if (empty($image_urls)) {
            wp_send_json_error('No slides selected for download');
        }
        
        // Generate base filename
        $base_filename = !empty($custom_filename) ? 
            sanitize_file_name($custom_filename) : 
            $this->get_filename_from_url($session_data['url']);
        
        try {
            // Download all selected images
            $image_paths = $this->download_images($image_urls);
            
            // Generate requested format
            $download_url = '';
            $file_path = '';
            
            switch ($format) {
                case 'pdf':
                    $file_path = $this->export_pdf($image_paths, $base_filename, $password);
                    break;
                case 'ppt':
                    $file_path = $this->export_ppt($image_paths, $base_filename);
                    break;
                case 'zip':
                    $file_path = $this->export_zip($image_paths, $base_filename);
                    break;
                default:
                    wp_send_json_error('Invalid download format');
            }
            
            // Clean up temporary image files
            $this->cleanup_images($image_paths);
            
            // Generate download URL
            $upload_dir = wp_upload_dir();
            $download_url = str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $file_path);
            
            wp_send_json_success(array(
                'download_url' => $download_url,
                'filename' => basename($file_path)
            ));
            
        } catch (Exception $e) {
            wp_send_json_error('Error generating download: ' . $e->getMessage());
        }
    }
    
    private function get_slide_images($url, $quality) {
        // Initialize cURL session
        $ch = curl_init();
        
        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        
        // Execute cURL session and get the content
        $html = curl_exec($ch);
        
        // Close cURL session
        curl_close($ch);
        
        if (!$html) {
            throw new Exception('Failed to fetch the SlideShare page');
        }
        
        // Use DOMDocument for HTML parsing
        $dom = new DOMDocument();
        @$dom->loadHTML($html);
        $xpath = new DOMXPath($dom);
        
        // Find all slide images
        $images = $xpath->query('//img[@data-testid="vertical-slide-image"]');
        $slide_urls = array();
        
        foreach ($images as $img) {
            $srcset = $img->getAttribute('srcset');
            if ($srcset) {
                $options = array_map('trim', explode(',', $srcset));
                
                // Select image based on quality
                switch ($quality) {
                    case 'low':
                        $selected = $options[0];
                        break;
                    case 'medium':
                        $selected = $options[count($options) / 2];
                        break;
                    case 'high':
                        $selected = $options[count($options) - 1];
                        break;
                    default:
                        $selected = $options[count($options) / 2]; // Default to medium
                }
                
                // Extract URL from selected option
                $parts = explode(' ', $selected);
                $image_url = $parts[0];
                
                // Ensure URL is absolute
                if (strpos($image_url, 'http') !== 0) {
                    $image_url = $this->make_absolute_url($url, $image_url);
                }
                
                $slide_urls[] = $image_url;
            }
        }
        
        return $slide_urls;
    }
    
    private function make_absolute_url($base, $relative) {
        $parsed_base = parse_url($base);
        
        if (strpos($relative, '//') === 0) {
            return $parsed_base['scheme'] . ':' . $relative;
        }
        
        if (strpos($relative, '/') === 0) {
            return $parsed_base['scheme'] . '://' . $parsed_base['host'] . $relative;
        }
        
        $path = isset($parsed_base['path']) ? $parsed_base['path'] : '';
        $path = preg_replace('#/[^/]*$#', '', $path) . '/';
        
        return $parsed_base['scheme'] . '://' . $parsed_base['host'] . $path . $relative;
    }
    
    private function download_images($image_urls) {
        $image_paths = array();
        
        foreach ($image_urls as $idx => $img_url) {
            $img_data = file_get_contents($img_url);
            $img_path = $this->download_dir . '/slide_' . ($idx + 1) . '.jpg';
            
            if (file_put_contents($img_path, $img_data) !== false) {
                $image_paths[] = $img_path;
            }
        }
        
        return $image_paths;
    }
    
    private function apply_slide_ranges($image_paths, $ranges_input) {
        $selected_images = array();
        preg_match_all('/(\d+)(?:-(\d+))?/', $ranges_input, $matches, PREG_SET_ORDER);
        
        foreach ($matches as $match) {
            $start = intval($match[1]) - 1;
            $end = isset($match[2]) ? intval($match[2]) - 1 : $start;
            
            for ($i = $start; $i <= $end; $i++) {
                if (isset($image_paths[$i])) {
                    $selected_images[] = $image_paths[$i];
                }
            }
        }
        
        return $selected_images;
    }
    
    private function export_pdf($image_paths, $base_filename, $password = '') {
        if (!class_exists('TCPDF')) {
            require_once(plugin_dir_path(__FILE__) . 'vendor/tcpdf/tcpdf.php');
        }
        
        $pdf_path = $this->download_dir . '/' . $base_filename . '.pdf';
        
        // Create new PDF document
        $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        
        // Set document information
        $pdf->SetCreator('SlideShare Downloader');
        $pdf->SetTitle($base_filename);
        
        // Remove header/footer
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        
        // Set margins
        $pdf->SetMargins(0, 0, 0);
        
        // Add each image as a page
        foreach ($image_paths as $img_path) {
            // Get image dimensions
            list($width, $height) = getimagesize($img_path);
            
            // Add page with image orientation
            $orientation = ($width > $height) ? 'L' : 'P';
            $pdf->AddPage($orientation);
            
            // Add image to fill the page
            $pdf->Image($img_path, 0, 0, $pdf->getPageWidth(), $pdf->getPageHeight(), '', '', '', false, 300, '', false, false, 0);
        }
        
        // Set PDF protection if password provided
        if (!empty($password)) {
            $pdf->SetProtection(array('print', 'copy'), $password, $password);
        }
        
        // Save PDF to file
        $pdf->Output($pdf_path, 'F');
        
        return $pdf_path;
    }
    
    private function export_ppt($image_paths, $base_filename) {
        if (!class_exists('ZipArchive')) {
            throw new Exception('ZipArchive extension is required for PPT generation');
        }
        
        $ppt_path = $this->download_dir . '/' . $base_filename . '.pptx';
        
        // We'll use a basic PPTX structure and add slides
        $template_path = plugin_dir_path(__FILE__) . 'assets/template.pptx';
        
        if (!file_exists($template_path)) {
            throw new Exception('PPTX template file not found');
        }
        
        // Copy template to destination
        copy($template_path, $ppt_path);
        
        // Open the PPTX as a ZIP file
        $zip = new ZipArchive();
        if ($zip->open($ppt_path) !== true) {
            throw new Exception('Failed to open PPTX file');
        }
        
        // Get slide template content
        $slide_template = $zip->getFromName('ppt/slides/slide1.xml');
        
        // Create presentation.xml with correct slide count
        $presentation_xml = $zip->getFromName('ppt/presentation.xml');
        $presentation_xml = preg_replace('/<p:sldIdLst>.*<\/p:sldIdLst>/s', 
            '<p:sldIdLst>' . $this->generate_slide_list(count($image_paths)) . '</p:sldIdLst>', 
            $presentation_xml);
        $zip->addFromString('ppt/presentation.xml', $presentation_xml);
        
        // Add each slide
        foreach ($image_paths as $index => $img_path) {
            $slide_number = $index + 1;
            
            // Create new relationship for image
            $rel_id = 'rId' . (1000 + $slide_number);
            
            // Add image to media folder
            $image_ext = pathinfo($img_path, PATHINFO_EXTENSION);
            $media_path = 'ppt/media/image' . $slide_number . '.' . $image_ext;
            $zip->addFile($img_path, $media_path);
            
            // Create slide content
            $slide_content = str_replace('{IMAGE_REL_ID}', $rel_id, $slide_template);
            $zip->addFromString('ppt/slides/slide' . $slide_number . '.xml', $slide_content);
            
            // Add slide relationship
            $slide_rel_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
                    <Relationship Id="' . $rel_id . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image' . $slide_number . '.' . $image_ext . '"/>
                </Relationships>';
            $zip->addFromString('ppt/slides/_rels/slide' . $slide_number . '.xml.rels', $slide_rel_xml);
        }
        
        // Update content types for slides
        $content_types = $zip->getFromName('[Content_Types].xml');
        $slide_overrides = '';
        for ($i = 1; $i <= count($image_paths); $i++) {
            $slide_overrides .= '<Override PartName="/ppt/slides/slide' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>';
        }
        $content_types = preg_replace('/<\/Types>/', $slide_overrides . '</Types>', $content_types);
        $zip->addFromString('[Content_Types].xml', $content_types);
        
        $zip->close();
        
        return $ppt_path;
    }
    
    private function generate_slide_list($count) {
        $output = '';
        for ($i = 1; $i <= $count; $i++) {
            $output .= '<p:sldId id="' . (256 + $i) . '" r:id="rId' . (2000 + $i) . '"/>';
        }
        return $output;
    }
    
    private function export_zip($image_paths, $base_filename) {
        $zip_path = $this->download_dir . '/' . $base_filename . '.zip';
        
        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new Exception('Failed to create ZIP file');
        }
        
        foreach ($image_paths as $index => $img_path) {
            $zip->addFile($img_path, 'slide_' . ($index + 1) . '.jpg');
        }
        
        $zip->close();
        
        return $zip_path;
    }
    
    private function cleanup_images($image_paths) {
        foreach ($image_paths as $path) {
            if (file_exists($path)) {
                @unlink($path);
            }
        }
    }
    
    public function cleanup_old_files() {
        // Delete files older than 24 hours
        $files = glob($this->download_dir . '/*');
        $now = time();
        
        foreach ($files as $file) {
            if (is_file($file)) {
                if ($now - filemtime($file) >= 24 * 60 * 60) {
                    @unlink($file);
                }
            }
        }
        
        // Clean up old sessions
        global $wpdb;
        $option_names = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM $wpdb->options WHERE option_name LIKE %s",
                'slideshare_session_%'
            )
        );
        
        foreach ($option_names as $option_name) {
            $session_data = get_option($option_name);
            if (isset($session_data['timestamp']) && ($now - $session_data['timestamp'] >= 24 * 60 * 60)) {
                delete_option($option_name);
            }
        }
    }
    
    private function get_filename_from_url($url) {
        preg_match('/slideshow\/([^\/]+)/', $url, $matches);
        if (isset($matches[1])) {
            $name = $matches[1];
        } else {
            $name = 'slides_' . date('Ymd_His');
        }
        return preg_replace('/[^a-zA-Z0-9_-]/', '_', $name);
    }
    
    private function generate_session_id() {
        return md5(uniqid('slideshare_', true));
    }
}

// Initialize the plugin
$slideshare_downloader = new SlideShare_Downloader();
