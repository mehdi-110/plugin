/**
 * SlideShare Downloader Frontend JavaScript
 */

jQuery(document).ready(function($) {
    // DOM elements
    const form = $('#slideshare-form');
    const urlInput = $('#slideshare-url');
    const qualitySelect = $('#slideshare-quality');
    const advancedToggle = $('#advanced-options-toggle');
    const advancedOptions = $('#advanced-options');
    const loadingElement = $('#slideshare-loading');
    const resultContainer = $('#slideshare-results');
    const slideContainer = $('#slides-container');
    const downloadOptions = $('#download-options');
    const backButton = $('#back-button');
    const selectAllBtn = $('#select-all-slides');
    const deselectAllBtn = $('#deselect-all-slides');
    const downloadForm = $('#download-form');
    const statusMessage = $('#status-message');
    
    let currentSessionId = null;
    let totalSlides = 0;
    
    // Initialize
    hideLoading();
    hideResults();
    
    // Toggle advanced options
    advancedToggle.on('click', function() {
        advancedOptions.slideToggle();
    });
    
    // Form submission
    form.on('submit', function(e) {
        e.preventDefault();
        
        const url = urlInput.val().trim();
        const quality = qualitySelect.val();
        
        if (!url) {
            showStatus('Please enter a valid SlideShare URL', 'error');
            return;
        }
        
        // Reset previous results
        hideResults();
        resetSlideContainer();
        
        // Show loading
        showLoading('Fetching slides from SlideShare...');
        
        // AJAX request to fetch slides
        $.ajax({
            url: slideshare_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_slideshare',
                nonce: slideshare_ajax.nonce,
                url: url,
                quality: quality
            },
            success: function(response) {
                hideLoading();
                
                if (response.success) {
                    const data = response.data;
                    currentSessionId = data.session_id;
                    totalSlides = data.total_slides;
                    
                    // Display slides
                    displaySlides(data.slides);
                    showResults();
                    showStatus(`Successfully fetched ${totalSlides} slides`, 'success');
                } else {
                    showStatus('Error: ' + response.data, 'error');
                }
            },
            error: function() {
                hideLoading();
                showStatus('Server error. Please try again later.', 'error');
            }
        });
    });
    
    // Back button
    backButton.on('click', function() {
        hideResults();
        resetForm();
    });
    
    // Select/Deselect all slides
    selectAllBtn.on('click', function() {
        $('.slide-checkbox').prop('checked', true);
    });
    
    deselectAllBtn.on('click', function() {
        $('.slide-checkbox').prop('checked', false);
    });
    
    // Download form submission
    downloadForm.on('submit', function(e) {
        e.preventDefault();
        
        const format = $('input[name="download-format"]:checked').val();
        if (!format) {
            showStatus('Please select a download format', 'error');
            return;
        }
        
        // Get selected slides
        const selectedSlides = [];
        $('.slide-checkbox:checked').each(function() {
            selectedSlides.push($(this).data('slide-id'));
        });
        
        if (selectedSlides.length === 0) {
            showStatus('Please select at least one slide', 'error');
            return;
        }
        
        // Get advanced options
        const password = $('#pdf-password').val();
        const customFilename = $('#custom-filename').val();
        const slideRange = $('#slide-range').val();
        
        // Show loading
        showLoading('Generating your download...');
        
        // AJAX request to generate download
        $.ajax({
            url: slideshare_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'generate_download',
                nonce: slideshare_ajax.nonce,
                session_id: currentSessionId,
                format: format,
                slides: selectedSlides,
                password: password,
                filename: customFilename,
                slide_range: slideRange
            },
            success: function(response) {
                hideLoading();
                
                if (response.success) {
                    const data = response.data;
                    
                    // Create download link
                    const downloadLink = $('<a>', {
                        text: `Download ${format.toUpperCase()} (${data.filename})`,
                        class: 'download-button',
                        href: data.download_url,
                        download: data.filename
                    });
                    
                    $('#download-link-container').html('').append(downloadLink);
                    showStatus('Download ready!', 'success');
                    
                    // Automatically start download
                    setTimeout(function() {
                        window.location.href = data.download_url;
                    }, 1000);
                    
                } else {
                    showStatus('Error: ' + response.data, 'error');
                }
            },
            error: function() {
                hideLoading();
                showStatus('Server error. Please try again later.', 'error');
            }
        });
    });
    
    // Function to display slides
    function displaySlides(slides) {
        slideContainer.empty();
        
        slides.forEach(function(slide) {
            const slideElement = $('<div>', {
                class: 'slide-item',
                'data-slide-id': slide.id
            });
            
            const checkboxWrapper = $('<div>', {
                class: 'slide-checkbox-wrapper'
            });
            
            const checkbox = $('<input>', {
                type: 'checkbox',
                class: 'slide-checkbox',
                id: 'slide-' + slide.id,
                'data-slide-id': slide.id,
                checked: slide.selected
            });
            
            const label = $('<label>', {
                for: 'slide-' + slide.id,
                text: 'Slide ' + slide.id
            });
            
            const slideImage = $('<img>', {
                src: slide.url,
                alt: 'Slide ' + slide.id,
                class: 'slide-preview'
            });
            
            const downloadBtn = $('<button>', {
                class: 'slide-download-btn',
                text: 'Download',
                'data-url': slide.url,
                'data-id': slide.id
            });
            
            // Add click event for individual slide download
            downloadBtn.on('click', function() {
                const url = $(this).data('url');
                const id = $(this).data('id');
                
                // Create a temporary link to download the image
                const link = document.createElement('a');
                link.href = url;
                link.download = 'slide_' + id + '.jpg';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });
            
            checkboxWrapper.append(checkbox, label);
            slideElement.append(checkboxWrapper, slideImage, downloadBtn);
            slideContainer.append(slideElement);
        });
    }
    
    // Utility functions
    function showLoading(message) {
        loadingElement.find('.loading-message').text(message || 'Loading...');
        loadingElement.show();
    }
    
    function hideLoading() {
        loadingElement.hide();
    }
    
    function showResults() {
        resultContainer.show();
        scrollToElement(resultContainer);
    }
    
    function hideResults() {
        resultContainer.hide();
    }
    
    function resetSlideContainer() {
        slideContainer.empty();
        $('#download-link-container').empty();
    }
    
    function resetForm() {
        // Don't clear the URL to make it easier for users to modify and resubmit
        // Just reset the results area
        currentSessionId = null;
        totalSlides = 0;
    }
    
    function showStatus(message, type) {
        statusMessage.removeClass('status-error status-success')
            .addClass('status-' + type)
            .text(message)
            .show();
        
        // Auto-hide after 5 seconds for success messages
        if (type === 'success') {
            setTimeout(function() {
                statusMessage.fadeOut();
            }, 5000);
        }
    }
    
    function scrollToElement(element) {
        $('html, body').animate({
            scrollTop: element.offset().top - 50
        }, 500);
    }
});
